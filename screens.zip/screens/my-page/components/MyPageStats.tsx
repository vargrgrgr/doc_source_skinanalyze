import React, { memo } from 'react';
import { StyleSheet, View } from 'react-native';
import { useSelector } from 'react-redux';

import colors from '../../../utils/colors';
import { paddingHorizontal } from '../../../utils/utils';
import { selectAverageScore, selectUser } from '../../../store/user';
import { selectAverageRecentTestScore } from '../../../store/test-results';
import Image from '../../../components/Image';
import ResultScoreCard from '../../../components/ResultScoreCard';
import ResultsDetails from '../../test-results/components/ResultsDetails';
import ResultStatCard from '../../../components/ResultStatCard';

const MyPageStats = () => {
  const user = useSelector(selectUser);
  const averageScore = useSelector(selectAverageScore);
  const averageRecentScore = useSelector(selectAverageRecentTestScore);

  return (
    <View style={styles.container}>
      <View style={styles.sectionTop}>
        <View style={styles.image}>
          <Image
            source={require('../../../assets/images/profile-picture.png')}
            style={styles.image}
          />
        </View>
        <View style={styles.statsContainer}>
          <ResultStatCard
            style={styles.marginBottom}
            title="종합점수"
            content={`${averageScore || averageRecentScore}점`}
          />
          <ResultStatCard
            title="피부나이"
            content={`${user?.skinAge || 0}세`}
          />
        </View>
      </View>
      <ResultScoreCard name="모공" style={styles.marginBottom} />
      <View style={styles.card}>
        <ResultsDetails data={user?.testData} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: paddingHorizontal,
  },
  sectionTop: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  image: {
    aspectRatio: 163 / 172,
    marginRight: 5,
    flex: 1,
    backgroundColor: colors.backgroundSecondary,
    borderRadius: 10,
  },
  statsContainer: {
    marginLeft: 5,
    flex: 1,
  },
  marginBottom: {
    marginBottom: 10,
  },
  card: {
    borderRadius: 10,
    backgroundColor: colors.backgroundSecondary,
    marginBottom: 20,
    padding: 24,
    paddingBottom: -20,
  },
});

export default memo(MyPageStats);
