import React from 'react';
import { StyleSheet } from 'react-native';
import { useQuery } from 'react-query';
import { useDispatch } from 'react-redux';

import Container from '../../components/Container';
import Hr from '../../components/Hr';
import { onFetchUser, User } from '../../store/user';
import MyPageHeader from './components/MyPageHeader';
import MyPageNav from './components/MyPageNav';
import MyPageStats from './components/MyPageStats';
import MyPageWeather from './components/MyPageWeather';

const mockedUser = {
  uid: '0',
  userId: 'doctorigin',
  userName: '홍길동',
  phoneNumber: '01012341234',
  email: 'example@doctorigin.com',
  questionnaire: {
    gender: 1 as 1 | 2,
    age: 1,
    skinAfterSkincare: 1,
    tZoneOil: 1,
    pimple: 1,
    dermatitis: 1,
    acne: 1,
    skinReaction: 1,
    concern: [0, 1],
  },
  authProvider: 'local',
  skinAge: 25,
  testData: {
    oil: 10,
    wrinkle: 20,
    pigment: 50,
    trouble: 30,
    pore: 70,
    flush: 30,
  },
};

const useFetchUser = () => {
  const dispatch = useDispatch();

  return useQuery('fetchUser', async () => {
    const { data } = await new Promise<{ data: User }>((resolve) => {
      setTimeout(() => {
        resolve({ data: mockedUser });
      }, 500);
    });
    dispatch(onFetchUser(data));
    return data;
  });
};

const MyPageScreen = () => {
  useFetchUser();

  return (
    <Container contentContainerStyle={styles.contentContainer} scrollEnabled>
      <MyPageHeader />
      <MyPageStats />
      <Hr big />
      <MyPageWeather />
      <Hr big />
      <MyPageNav />
    </Container>
  );
};

const styles = StyleSheet.create({
  contentContainer: {
    paddingTop: 40,
    paddingBottom: 10,
  },
});

export default MyPageScreen;
