

// sex, age, q1, q2, q3, q4, q5, q6