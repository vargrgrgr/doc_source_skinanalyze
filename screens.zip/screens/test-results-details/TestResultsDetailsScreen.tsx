import React from 'react';
import { StyleSheet, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useSelector } from 'react-redux';

import colors from '../../utils/colors';
import { paddingHorizontal } from '../../utils/utils';
import { selectAverageScore } from '../../store/user';
import { selectAverageRecentTestScore } from '../../store/test-results';
import { TestResultsDetailsScreenNavigationProp } from '../../navigators/navigation.types';
import BottomBar from '../../components/BottomBar';
import Button from '../../components/Button';
import Container from '../../components/Container';
import FlareIcon from '../../assets/icons/flare.svg';
import ResultStatCard from '../../components/ResultStatCard';
import SkinAcneIcon from '../../assets/icons/skin-acne.svg';
import SkinHairIcon from '../../assets/icons/skin-hair.svg';
import StripesIcon from '../../assets/icons/stripes.svg';
import TestResultsDetailsItem from './components/TestResultsDetailsItem';
import TextBold from '../../components/TextBold';
import TextLight from '../../components/TextLight';
import WavesIcon from '../../assets/icons/waves.svg';

const TestResultsDetailsScreen = () => {
  const navigation = useNavigation<TestResultsDetailsScreenNavigationProp>();
  const averageScore = useSelector(selectAverageScore);
  const averageRecentScore = useSelector(selectAverageRecentTestScore);
  const goToSummary = () => navigation.navigate('TestResultsSummary');

  return (
    <>
      <Container style={styles.contentContainer} scrollEnabled>
        <TextBold style={styles.username}>홍길동 회원님의</TextBold>
        <TextLight style={styles.welcome}>진단 결과입니다!</TextLight>
        <View style={styles.statsContainer}>
          <ResultStatCard
            style={styles.statsCard}
            title="종합점수"
            content={`${averageScore || averageRecentScore}점`}
          />
          <ResultStatCard
            style={styles.statsCard}
            title="피부나이"
            content="25세"
          />
        </View>
        <TestResultsDetailsItem name="주름" value={10} icon={WavesIcon} />
        <TestResultsDetailsItem name="색소" value={30} icon={SkinAcneIcon} />
        <TestResultsDetailsItem name="트러블" value={40} icon={StripesIcon} />
        <TestResultsDetailsItem name="모공" value={30} icon={SkinHairIcon} />
        <TestResultsDetailsItem name="홍조" value={100} icon={FlareIcon} />
      </Container>
      <BottomBar>
        <Button onPress={goToSummary}>진단 결과</Button>
      </BottomBar>
    </>
  );
};

const styles = StyleSheet.create({
  contentContainer: {
    paddingHorizontal: paddingHorizontal,
  },
  username: {
    fontSize: 18,
  },
  welcome: {
    fontSize: 18,
    marginBottom: 30,
  },
  card: {
    borderRadius: 10,
    backgroundColor: colors.backgroundSecondary,
    marginBottom: 10,
  },
  statsContainer: {
    flexDirection: 'row',
    marginHorizontal: -5,
    marginBottom: 10,
  },
  statsCard: {
    marginHorizontal: 5,
  },
});

export default TestResultsDetailsScreen;
