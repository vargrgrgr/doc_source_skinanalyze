import React, { memo } from 'react';
import { StyleSheet, View } from 'react-native';
import { Source } from 'react-native-fast-image';

import colors from '../../../utils/colors';
import AppText from '../../../components/AppText';
import HeartIcon from '../../../assets/icons/heart.svg';
import Image from '../../../components/Image';
import TouchableRipple from '../../../components/TouchableRipple';

interface Props {
  uri: number | Source;
  title: string;
  likeCount: number;
}

const MainColumnsItem = ({ uri, title, likeCount }: Props) => {
  return (
    <View style={styles.container}>
      <TouchableRipple>
        <Image style={styles.image} source={uri} />
        <AppText style={styles.title} numberOfLines={1}>
          {title}
        </AppText>
        <View style={styles.likeContainer}>
          <HeartIcon />
          <AppText style={styles.likeCount} numeric>
            {likeCount}
          </AppText>
        </View>
      </TouchableRipple>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 5,
    width: '50%',
    marginTop: 20,
  },
  image: {
    aspectRatio: 1,
    borderRadius: 5,
  },
  title: {
    marginTop: 12,
    marginBottom: 4,
  },
  likeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  likeCount: {
    fontSize: 12,
    color: colors.textTertiary,
  },
});

export default memo(MainColumnsItem);
