import React, { memo } from 'react';
import { View, StyleSheet } from 'react-native';
import { useQuery } from 'react-query';

import colors from '../../../utils/colors';
import MainColumnsItem from './MainColumnsItem';
import MainColumnsItemPlaceholder from './MainColumnsItemPlaceholder';
import TextBold from '../../../components/TextBold';
import TextDemiLight from '../../../components/TextDemiLight';
import TouchableRipple from '../../../components/TouchableRipple';

const mockedColumns = [
  {
    id: 1,
    title: '닥터그린의 뷰티칼럼입니다',
    likeCount: 123,
    uri: require('../../../assets/images/column1.png'),
  },
  {
    id: 2,
    title: '닥터그린의 뷰티칼럼입니다',
    likeCount: 123,
    uri: require('../../../assets/images/column2.png'),
  },
  {
    id: 3,
    title: '닥터그린의 뷰티칼럼입니다',
    likeCount: 123,
    uri: require('../../../assets/images/column3.png'),
  },
  {
    id: 4,
    title: '닥터그린의 뷰티칼럼입니다',
    likeCount: 123,
    uri: require('../../../assets/images/column4.png'),
  },
  {
    id: 5,
    title: '닥터그린의 뷰티칼럼입니다',
    likeCount: 123,
    uri: require('../../../assets/images/column5.png'),
  },
  {
    id: 6,
    title: '닥터그린의 뷰티칼럼입니다',
    likeCount: 123,
    uri: require('../../../assets/images/column6.png'),
  },
];

type Column = {
  id: number;
  title: string;
  likeCount: number;
  uri: any;
};

const useMainColumns = () => {
  return useQuery('mainColumns', async () => {
    const { data } = await new Promise<{ data: Column[] }>((resolve) => {
      setTimeout(() => {
        resolve({ data: mockedColumns });
      }, 500);
    });
    return data;
  });
};

const MainColumns = () => {
  const { isLoading, data: columns } = useMainColumns();

  const getPlaceHolder = () =>
    [...Array(4).keys()].map((i) => <MainColumnsItemPlaceholder key={i} />);

  const getColumns = () =>
    columns?.map(({ id, ...rest }) => <MainColumnsItem key={id} {...rest} />);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TextBold>뷰티 칼럼</TextBold>
        <TouchableRipple>
          <TextDemiLight style={styles.moreLink}>전체보기</TextDemiLight>
        </TouchableRipple>
      </View>
      <View style={styles.columnsList}>
        {isLoading ? getPlaceHolder() : getColumns()}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginTop: 40,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  moreLink: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  columnsList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginHorizontal: -5,
  },
  separator: {
    width: 10,
  },
});

export default memo(MainColumns);
