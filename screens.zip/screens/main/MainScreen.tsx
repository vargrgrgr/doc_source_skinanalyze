import React from 'react';
import { StyleSheet, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { ModalResultType } from 'react-native-use-modal';
import { useSelector } from 'react-redux';

import { MainScreenNavigationProp } from '../../navigators/navigation.types';
import { paddingHorizontal } from '../../utils/utils';
import { selectHasTestResults } from '../../store/test-results';
import { selectIsLoggedIn } from '../../store/user';
import useSimpleModal from '../../hooks/useSimpleModal';
import Container from '../../components/Container';
import MainBanner from './components/MainBanner';
import MainCard from './components/MainCard';
import MainColumns from './components/MainColumns';
import MainFooter from './components/MainFooter';
import ReportIcon from '../../assets/icons/report.svg';
import ScanSkinIcon from '../../assets/icons/scan-skin.svg';

const MainScreen = () => {
  const navigation = useNavigation<MainScreenNavigationProp>();
  const isLoggedIn = useSelector(selectIsLoggedIn);
  const hasTestResults = useSelector(selectHasTestResults);
  const simpleModal = useSimpleModal();

  const goToCamera = () => navigation.navigate('Camera');

  const goToRecentResult = async () => {
    if (isLoggedIn) {
      if (true) {
        navigation.navigate('TestResults');
      } else {
        const result = await simpleModal.show({
          message: '최근 측정결과가 없습니다.',
          confirmText: '피부 측정',
        });

        if (result.type === ModalResultType.CONFIRM) {
          navigation.navigate('Camera');
        }
      }
    } else {
      navigation.navigate('Login');
    }
  };

  return (
    <Container contentContainerStyle={styles.container} scrollEnabled>
      <MainBanner />
      <View style={styles.section}>
        <MainCard
          title="내 피부를 알아봅시다"
          textLink="피부 촬영하기"
          icon={ScanSkinIcon}
          onPress={goToCamera}
        />
        <MainCard
          title="최근 피부 분석 결과"
          textLink="결과 확인하기"
          icon={ReportIcon}
          onPress={goToRecentResult}
        />
      </View>
      <MainColumns />
      <MainFooter />
    </Container>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal,
  },
  section: {
    flexDirection: 'row',
    marginHorizontal: -5,
  },
  marginRight: {
    marginRight: 10,
  },
});

export default MainScreen;
