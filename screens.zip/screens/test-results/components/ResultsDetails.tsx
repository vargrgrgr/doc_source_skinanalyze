import React, { FC, memo } from 'react';
import { StyleSheet, View } from 'react-native';
import { SvgProps } from 'react-native-svg';

import colors from '../../../utils/colors';
import { paddingHorizontal } from '../../../utils/utils';
import FlareIcon from '../../../assets/icons/flare.svg';
import HappyFace from '../../../assets/icons/emoticon-happy.svg';
import NeutralFace from '../../../assets/icons/emoticon-neutral.svg';
import ResultBar from '../../../components/ResultBar';
import SadFace from '../../../assets/icons/emoticon-sad.svg';
import SkinAcneIcon from '../../../assets/icons/skin-acne.svg';
import SkinHairIcon from '../../../assets/icons/skin-hair.svg';
import StripesIcon from '../../../assets/icons/stripes.svg';
import TextBold from '../../../components/TextBold';
import WaterThirdIcon from '../../../assets/icons/water-third-white.svg';
import WavesIcon from '../../../assets/icons/waves.svg';

const resultsLabel = [
  { label: '유수분', name: 'oil', icon: WaterThirdIcon },
  { label: '주름', name: 'wrinkle', icon: WavesIcon },
  { label: '색소', name: 'pigment', icon: FlareIcon },
  { label: '트러블', name: 'trouble', icon: SkinAcneIcon },
  { label: '모공', name: 'pore', icon: SkinHairIcon },
  { label: '홍조', name: 'flush', icon: StripesIcon },
];

const ResultsDetails = ({
  data,
}: {
  data?: { [key: string]: number } | null;
}) => {
  const getResult = ({
    label,
    name,
    icon,
    value,
  }: {
    label: string;
    name: string;
    icon: FC<SvgProps>;
    value: number;
  }) => {
    const Icon = icon;

    return (
      <View key={name} style={styles.resultContainer}>
        <View style={styles.resultNameContainer}>
          <Icon fill={colors.text} />
          <TextBold>{label}</TextBold>
        </View>
        <View style={styles.resultBarContainer}>
          <ResultBar value={value} />
          <View style={styles.facesContainer}>
            <SadFace fill={colors.icon} />
            <NeutralFace fill={colors.icon} />
            <HappyFace fill={colors.icon} />
          </View>
        </View>
      </View>
    );
  };

  if (!data) {
    return null;
  }

  return (
    <View>
      {resultsLabel.map((r, i) =>
        getResult({ ...r, value: data?.[r.name] || 0 }),
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  resultContainer: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  resultNameContainer: {
    width: 74 + 8 - paddingHorizontal,
    marginTop: -6,
    marginLeft: -8,
    paddingRight: 8,
    alignItems: 'center',
  },
  resultBarContainer: {
    flex: 1,
  },
  facesContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
});

export default memo(ResultsDetails);
