import React, { useEffect, useRef, useState } from 'react';
import { View, StyleSheet, Image, ImageBackground } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useDispatch, useSelector } from 'react-redux';
import { useQuery } from 'react-query';
import Canvas, {Image as CanvasImage, Path2D} from 'react-native-canvas';
import ImageResizer from 'react-native-image-resizer';

import RNFS from 'react-native-fs';

import colors from '../../utils/colors';
import {
  onTestResultsDone,
  selectRecentTestResults,
} from '../../store/test-results';
import { paddingHorizontal } from '../../utils/utils';
import { selectIsLoggedIn } from '../../store/user';
import {
  TestResultsScreenNavigationProp,
  TestResultsScreenProp,
} from '../../navigators/navigation.types';
import useLoading from '../../hooks/useLoading';
import BottomBar from '../../components/BottomBar';
import Button from '../../components/Button';
import Container from '../../components/Container';
import ResultsDetails from './components/ResultsDetails';
import ResultsGraph from './components/ResultsGraph';
import ResultsHeader from './components/ResultsHeader';

import OpenCV from '../../NativeModules/OpenCV';

const placeholderData = {
  oil: 0,
  wrinkle: 0,
  pigment: 0,
  trouble: 0,
  pore: 0,
  flush: 0,
};

const useTestResults = () => {
  const { photo } = useRoute<TestResultsScreenProp>().params || {};
  const dispatch = useDispatch();
  const recentResults = useSelector(selectRecentTestResults);


  return useQuery(
    ['testResults', photo],
    async () => {
      if (!photo && !__DEV__) {
        return recentResults || placeholderData;
      }

      const { data } = await new Promise<{ data: { [key: string]: number } }>(
        (resolve) => {
          setTimeout(() => {
            const mockedResults = {
              
              oil: Math.floor(100),
              wrinkle: Math.floor(65+((Math.random()-0.5) * 50)),
              pigment: Math.floor(45+ (Math.random() * 40)),
              trouble: Math.floor(55+ (Math.random() * 25)),
              pore: Math.floor(55+ (Math.random() * 25)),
              flush: Math.floor(40+ ((Math.random()-0.3) * 50)),
            };

            dispatch(onTestResultsDone(mockedResults));
            resolve({ data: mockedResults });
          }, 2000);
        },
      );
      return data;
    },
    { placeholderData, cacheTime: 0 },
  );
};

const TestResultsScreen = () => {
  const { data, isFetching } = useTestResults();
  const [isloading, setisloading] = useState(false);
  useLoading(isFetching);
  const navigation = useNavigation<TestResultsScreenNavigationProp>();
  const isLoggedIn = useSelector(selectIsLoggedIn);
  const photo = useRoute<TestResultsScreenProp>().params.photo;
  const photoprop='files:/'+useRoute<TestResultsScreenProp>().params.photo.path;
  //console.log(photoprop);
  var takeone = false;
  var first = true;


  const handleCanvas = async (canvas) => {
    if(canvas==null) return;

      const ctx=canvas.getContext('2d');
      canvas.width = 640;
      console.log("canvas width:"+canvas.width);
      canvas.height = 480;
      console.log("canvas height:"+canvas.height);
      const fimage = new CanvasImage(canvas, 640, 480);
      console.log("canvas draw");
      fimage.width = photo.width;
      console.log("image width:"+fimage.width);
      fimage.height = photo.height;
      console.log("image width:"+fimage.height);  
      ImageResizer.createResizedImage(photo.path, 640, 480, 'JPEG', 80).then((resizedImageUri) => {
        console.log("uri:"+resizedImageUri.path);
        if(takeone == false){
          takeone = true;
          RNFS.readFile(resizedImageUri.path, 'base64').then(res =>{
            fimage.src='data:image/jpeg;base64,'+res;
          }).catch((err) => {
            console.log(err)
          })
        }
        fimage.width = 640;
        fimage.height = 480;
      })
    if(isloading==false){
      setisloading(true);
      fimage.addEventListener("load", () => {
        console.log("Have successfully loaded ")
        ctx.drawImage(fimage, 0, 0);
      });
      setisloading(false);
    }
  };
  const navigate = async () => {
    //var Output: string;
    //Output = await OpenCV.FaceProc(photo.path,photo.width,photo.height);
    //if (Output!="null"){
    //  console.log(Output);
    //}

    if (isLoggedIn) {
      navigation.navigate('TestResultsDetails');
     // console.log("go detail ")
    } else {
      navigation.navigate('Login');
      //console.log("login ")
    }
    
  };

  /*
  inside container
          <View style={styles.resultsContainer}>
          <Canvas ref={handleCanvas}
          style={{borderWidth: 0, borderColor: 'black',
          transform: [
            { rotateX: "0deg" },
            { rotateY: "180deg" },
            { rotateZ: "0deg" },
            { translateX: 264 }
          ]
        }}
        />
  */
  return (
    <>
      <Container scrollEnabled contentContainerStyle={styles.contentContainer}>
       <View style={styles.resultsContainer}>
          <ResultsHeader data={data} />
          <ResultsGraph data={data} />
          <ResultsDetails data={data} />
        </View>
      </Container>
      <BottomBar>
        <Button onPress={navigate}>
          {'상세 측정 결과 확인'}
        </Button>
      </BottomBar>
    </>
  );
};

const styles = StyleSheet.create({
  ImageContainer: {
    paddingHorizontal,
    flex: 1,
  },
  contentContainer: {
    backgroundColor: colors.backgroundSecondary,
    paddingTop: 20,
    paddingBottom: 16,
    paddingHorizontal: 24,
  },
  face: {
    width: 300,
    height: 300,
    resizeMode: 'cover',
    borderWidth: 1,
    borderColor: 'red'
  },
  header: {
    height: 64,
    justifyContent: 'center',
    alignItems: 'center',
  },
  resultsContainer: {
    backgroundColor: colors.backgroundSecondary,
    paddingTop: 20,
    paddingBottom: 16,
    paddingHorizontal: 24,
    borderRadius: 10,
  },
});

export default TestResultsScreen;
