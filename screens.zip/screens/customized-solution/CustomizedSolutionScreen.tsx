import React, { useCallback, useRef } from 'react';
import { StyleSheet, View } from 'react-native';
import { BottomSheetModal } from '@gorhom/bottom-sheet';
import { Source } from 'react-native-fast-image';
import { useQuery } from 'react-query';

import colors from '../../utils/colors';
import { paddingHorizontal } from '../../utils/utils';
import BottomBar from '../../components/BottomBar';
import Button from '../../components/Button';
import Container from '../../components/Container';
import CustomizedSolutionBottomSheet from './components/CustomizedSolutionBottomSheet';
import CustomizedSolutionItem from './components/CustomizedSolutionItem';
import CustomizedSolutionHeader from './components/CustomizedSolutionHeader';
import CustomizedSolutionPlaceHolder from './components/CustomizedSolutionPlaceHolder';

const mockedProducts = [
  {
    id: 1,
    picture: require('../../assets/images/productlarge1.png'),
    name: '닥터리진 A2 솔루션 토너',
    description: '수분감이 대박 많은 토너',
    discount: 10,
    price: 15000,
  },
  {
    id: 2,
    picture: require('../../assets/images/product2.png'),
    name: '닥터리진 A2 솔루션 토너',
    description: '수분감이 대박 많은 토너',
    discount: 10,
    price: 15000,
  },
  {
    id: 3,
    picture: require('../../assets/images/product3.png'),
    name: '닥터리진 A2 솔루션 토너',
    description: '수분감이 대박 많은 토너',
    discount: 10,
    price: 15000,
  },
  {
    id: 4,
    picture: require('../../assets/images/product2.png'),
    name: '닥터리진 A2 솔루션 토너',
    description: '수분감이 대박 많은 토너',
    discount: 10,
    price: 15000,
  },
  {
    id: 5,
    picture: require('../../assets/images/product3.png'),
    name: '닥터리진 A2 솔루션 토너',
    description: '수분감이 대박 많은 토너',
    discount: 10,
    price: 15000,
  },
  {
    id: 6,
    picture: require('../../assets/images/product3.png'),
    name: '닥터리진 A2 솔루션 토너',
    description: '수분감이 대박 많은 토너',
    discount: 10,
    price: 15000,
  },
];

type Product = {
  id: number;
  picture: number | Source;
  name: string;
  description: string;
  discount?: number;
  price: number;
};

const useCustomizedSolution = () => {
  return useQuery(
    'customizedSolutionn',
    async () => {
      const { data } = await new Promise<{ data: Product[] }>((resolve) => {
        setTimeout(() => {
          resolve({ data: mockedProducts });
        }, 1000);
      });
      return data;
    },
    { cacheTime: 0 },
  );
};

const CustomizedSolutionScreen = () => {
  const { data: products, isLoading } = useCustomizedSolution();
  const bottomSheetModalRef = useRef<BottomSheetModal>(null);

  const onPurchaseButtonPress = () => {
    bottomSheetModalRef.current?.present();
  };

  const keyExtractor = useCallback((item: Product) => `${item.id}`, []);
  const renderItem = useCallback(
    ({ item }: { item: Product }) => <CustomizedSolutionItem {...item} />,
    [],
  );

  return (
    <>
      {isLoading ? (
        <CustomizedSolutionPlaceHolder />
      ) : (
        <Container
          flatList
          contentContainerStyle={styles.contentContainer}
          ListHeaderComponent={<CustomizedSolutionHeader />}
          data={products}
          keyExtractor={keyExtractor}
          renderItem={renderItem}
          ItemSeparatorComponent={() => <View style={styles.separator} />}
        />
      )}
      <BottomBar>
        <Button onPress={onPurchaseButtonPress} loading={isLoading}>
          구매하기
        </Button>
      </BottomBar>
      <CustomizedSolutionBottomSheet ref={bottomSheetModalRef} />
    </>
  );
};

const styles = StyleSheet.create({
  contentContainer: {
    paddingTop: 30,
    paddingBottom: 5,
  },
  separator: {
    marginVertical: 5,
    marginHorizontal: paddingHorizontal,
    backgroundColor: colors.disabled,
    height: 1,
    width: '100%',
  },
});

export default CustomizedSolutionScreen;
