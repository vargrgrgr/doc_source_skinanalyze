import React, { memo } from 'react';
import { View, StyleSheet } from 'react-native';

import { paddingHorizontal } from '../../../utils/utils';
import TextBold from '../../../components/TextBold';
import TextLight from '../../../components/TextLight';

const CustomizedSolutionHeader = () => {
  return (
    <View style={styles.header}>
      <TextLight style={styles.bigFont}>
        <TextBold style={styles.bigFont}>홍길동 회원님</TextBold>
        에게는
      </TextLight>
      <TextLight style={styles.bigFont}>
        <TextBold style={styles.bigFont}>주름전문 솔루션</TextBold>을
        제안드립니다.
      </TextLight>
    </View>
  );
};

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: paddingHorizontal,
    marginBottom: 15,
  },
  bigFont: {
    fontSize: 18,
  },
});

export default memo(CustomizedSolutionHeader);
