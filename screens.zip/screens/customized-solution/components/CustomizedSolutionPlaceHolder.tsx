import React, { useCallback } from 'react';
import { StyleSheet } from 'react-native';

import Container from '../../../components/Container';
import CustomizedSolutionHeader from './CustomizedSolutionHeader';
import CustomizedSolutionItemPlaceholder from './CustomizedSolutionItemPlaceholder';

const CustomizedSolutionPlaceHolder = () => {
  const keyExtractor = useCallback((item: number) => `${item}`, []);
  const renderItem = useCallback(
    () => <CustomizedSolutionItemPlaceholder />,
    [],
  );

  return (
    <Container
      flatList
      contentContainerStyle={styles.contentContainer}
      ListHeaderComponent={<CustomizedSolutionHeader />}
      data={[...Array(9).keys()]}
      keyExtractor={keyExtractor}
      renderItem={renderItem}
    />
  );
};

const styles = StyleSheet.create({
  contentContainer: {
    paddingTop: 30,
    paddingBottom: 5,
  },
});

export default CustomizedSolutionPlaceHolder;
