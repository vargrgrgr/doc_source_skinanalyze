import React, { useEffect, useRef, useState } from 'react';
import { View, StyleSheet, Image, ImageBackground } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useDispatch, useSelector } from 'react-redux';
import { useQuery } from 'react-query';
import { selectIsLoggedIn } from '../../store/user';
import {
  ImageProcScreenNavigationProp,
  ImageProcScreenProp,
} from '../../navigators/navigation.types';
import Container from '../../components/Container';
import OpenCV from '../../NativeModules/OpenCV';
import { sleep } from '../../utils/utils';

const placeholderData = {
  oil: 0,
  wrinkle: 0,
  pigment: 0,
  trouble: 0,
  pore: 0,
  flush: 0,
};



const ImageProcScreen = () => {
  const [isloading, setisloading] = useState(false);
  const navigation = useNavigation<ImageProcScreenNavigationProp>();
  const isLoggedIn = useSelector(selectIsLoggedIn);
  const photo = useRoute<ImageProcScreenProp>().params.photo;
  const photoprop='files:/'+useRoute<ImageProcScreenProp>().params.photo.path;
  console.log(photoprop);
  var takeone = false;
  var first = true;
  var num="0";


  useEffect(() => {
    // declare the data fetching function
    const navigate = async () => {
      FaceImgProc(photo.path).then((result: string)=>{
        console.log(photo.path);
        num=result; 
        console.log(num);
        console.log("num");
        navigation.navigate('TestResults', { photo });
      });
    }
  
    // call the function
    navigate()
      // make sure to catch any error
      .catch(console.error);
  }, []);

const FaceImgProc=async (path:string)=>{
  const k=OpenCV.FaceProc(path);
  return k;
}

  return (
    <>
      <Container scrollEnabled contentContainerStyle={styles.ImageContainer}>
        <View style={styles.resultsContainer}>
            <Image
             style ={{resizeMode: "contain", width: "100%", height:"100%", opacity: 0.7}}
             source={require('../../assets/images/sample.gif')}
            />
        </View>
      </Container>
    </>
  );
};

const styles = StyleSheet.create({
  ImageContainer: {
    flex: 1,
  },
  resultsContainer: {
    backgroundColor: '#000',
  },
});

export default ImageProcScreen;
